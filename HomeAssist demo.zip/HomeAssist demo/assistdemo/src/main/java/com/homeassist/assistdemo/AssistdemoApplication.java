package com.homeassist.assistdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AssistdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(AssistdemoApplication.class, args);
	}

}
